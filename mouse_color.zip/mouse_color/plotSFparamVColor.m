function plotSFparamVColor(tcP,pColordum,pSdum,pSlohi)


%%
idB = find(~isnan(tcP.sfprefA.*tcP.sfprefB.*tcP.sfCoMA.*tcP.sfCoMB.*tcP.sfhcoA.*tcP.sfhcoB.*tcP.sfBPA.*tcP.sfBPB));
idx = find(pSdum(idB)>pSlohi(1) & pSdum(idB)<pSlohi(2));
%idx = find(pSAll(idB)<.2);
idB = idB(idx);

%Cull the poplation
pColordum = pColordum(idB);
vars = fields(tcP);
for i = 1:length(vars)
    eval(['tcP.' vars{i} ' = tcP.' vars{i} '(idB);'])
end


idLum = find(pColordum>-10 & pColordum<1/3);
idColorLum = find(pColordum>1/3 & pColordum<2/3);
idColor = find(pColordum>2/3 & pColordum<10);


%idB = find(pSAll<.1 | pSAll>.6);


sfdom = logspace(log10(.0125),log10(.4),5);

figure,
subplot(5,2,1)
loglog([sfdom(1) sfdom(end)],[sfdom(1) sfdom(end)],'k'), hold on
loglog(tcP.sfprefA(idColorLum),tcP.sfprefB(idColorLum),'.r'),
loglog(tcP.sfprefA(idLum),tcP.sfprefB(idLum),'.k'), 
loglog(tcP.sfprefA(idColor),tcP.sfprefB(idColor),'or'),
%loglog(tcP.sfprefA(idB),tcP.sfprefB(idB),'.k'),
set(gca,'XTick', sfdom(1:2:end), 'YTick', sfdom(1:2:end))
xlabel('Sf peak loc; Lum ')
ylabel('Sf peak loc; Color ')
axis square
xlim([sfdom(1) sfdom(end)]), ylim([sfdom(1) sfdom(end)])
id = find(~isnan(tcP.sfprefA.*tcP.sfprefB));
[r p] = corrcoef(log2(tcP.sfprefA),log2(tcP.sfprefB));
title(['r=' num2str(round(r(1,2)*100)/100) '; p=' num2str(p(1,2))])

subplot(5,2,2)
histogram(log2(tcP.sfprefA./tcP.sfprefB),[-4:.25:4],'FaceColor',[1 1 1])
set(gca,'TickDir','out')
mu = nanmean(log2(tcP.sfprefA./tcP.sfprefB));
[h p] = ttest(log2(tcP.sfprefA./tcP.sfprefB));
title(['geomu=' num2str(2.^mu) ' p=' num2str(p)])
xlabel('log(x)-log(y)')

subplot(5,2,3)
loglog([sfdom(1) sfdom(end)],[sfdom(1) sfdom(end)],'k'), hold on
loglog(tcP.sfCoMA(idColorLum),tcP.sfCoMB(idColorLum),'.r'), hold on, 
loglog(tcP.sfCoMA(idLum),tcP.sfCoMB(idLum),'.k'), 
loglog(tcP.sfCoMA(idColor),tcP.sfCoMB(idColor),'or'), 
set(gca,'XTick', sfdom(1:2:end), 'YTick', sfdom(1:2:end))
xlabel('Sf CoM; Lum ')
ylabel('Sf CoM; Color ')
axis square
xlim([sfdom(1) sfdom(end)]), ylim([sfdom(1) sfdom(end)])
id = find(~isnan(tcP.sfCoMA.*tcP.sfCoMB));
[r p] = corrcoef(log2(tcP.sfCoMA),log2(tcP.sfCoMB));
title(['r=' num2str(round(r(1,2)*100)/100) '; p=' num2str(p(1,2))])

subplot(5,2,4)
histogram(log2(tcP.sfCoMA./tcP.sfCoMB),[-3:.25:3],'FaceColor',[1 1 1])
set(gca,'TickDir','out')
mu = nanmean(log2(tcP.sfCoMA./tcP.sfCoMB));
[hyp p] = ttest(log2(tcP.sfCoMA./tcP.sfCoMB));
title(['geomu=' num2str(2.^mu) ' p=' num2str(p)])
xlabel('log(x)-log(y)')

subplot(5,2,5)
loglog([sfdom(1) sfdom(end) ],[sfdom(1) sfdom(end)],'k'), hold on,
n1 = .05*randn(size(idColorLum)); n2 = .05*randn(size(idColorLum));
loglog(2.^(log2(tcP.sfhcoA(idColorLum))+n1),2.^(log2(tcP.sfhcoB(idColorLum))+n2),'.r'),
n1 = .05*randn(size(idLum)); n2 = .05*randn(size(idLum));
loglog(2.^(log2(tcP.sfhcoA(idLum))+n1),2.^(log2(tcP.sfhcoB(idLum))+n2),'.k')
n1 = .05*randn(size(idColor)); n2 = .05*randn(size(idColor));
loglog(2.^(log2(tcP.sfhcoA(idColor))+n1),2.^(log2(tcP.sfhcoB(idColor))+n2),'or')
set(gca,'XTick', sfdom(1:2:end), 'YTick', sfdom(1:2:end))
xlabel('Sf high pass cutoff; Lum ')
ylabel('Sf high pass cutoff; Color ')
xlim([sfdom(1) sfdom(end)]), ylim([sfdom(1) sfdom(end)])
axis square
id = find(~isnan(tcP.sfhcoA.*tcP.sfhcoB));
[r p] = corrcoef(log2(tcP.sfhcoA),log2(tcP.sfhcoB));
title(['r=' num2str(round(r(1,2)*100)/100) '; p=' num2str(p(1,2))])

subplot(5,2,6)
histogram(log2(tcP.sfhcoA./tcP.sfhcoB),[-4:.5:4],'FaceColor',[1 1 1])
set(gca,'TickDir','out')
mu = nanmean(log2(tcP.sfhcoA./tcP.sfhcoB));
[hyp p] = ttest(log2(tcP.sfhcoA./tcP.sfhcoB));
title(['geomu=' num2str(2.^mu) ' p=' num2str(p)])
xlabel('log(x)-log(y)')

subplot(5,2,7)
plot([0 1],[0 1],'k'), hold on
scatter(tcP.sfBPA(idColorLum),tcP.sfBPB(idColorLum),'.r')
scatter(tcP.sfBPA(idLum),tcP.sfBPB(idLum),'.k')
scatter(tcP.sfBPA(idColor),tcP.sfBPB(idColor),'or')
xlabel('Sf bandpass; Lum ')
ylabel('Sf bandpass; Color ')
axis square
id = find(~isnan(tcP.sfBPA.*tcP.sfBPB));
[r p] = corrcoef(tcP.sfBPA,tcP.sfBPB);
title(['r=' num2str(round(r(1,2)*100)/100) '; p=' num2str(p(1,2))])

subplot(5,2,8)
h  = histogram(tcP.sfBPA - tcP.sfBPB,[-1:.1:1],'FaceColor',[1 1 1]); 
%plot(h.BinEdges(1:end-1),cumsum(h.Values/sum(h.Values)))
set(gca,'TickDir','out')
mu = nanmedian(tcP.sfBPA - tcP.sfBPB);
[hyp p] = ttest(tcP.sfBPA - tcP.sfBPB);
title(['mu=' num2str(mu) ' p=' num2str(p)])
xlabel('x-y')


subplot(5,2,9)
loglog([sfdom(1) sfdom(end) ],[sfdom(1) sfdom(end)],'k'), hold on
loglog(tcP.sfBWA(idColorLum),tcP.sfBWB(idColorLum),'.r')
loglog(tcP.sfBWA(idLum),tcP.sfBWB(idLum),'.k')
loglog(tcP.sfBWA(idColor),tcP.sfBWB(idColor),'or')
set(gca,'XTick', sfdom(1:2:end), 'YTick', sfdom(1:2:end))
xlabel('Sf bandwidth; Lum ')
ylabel('Sf bandwidth; Color ')
xlim([sfdom(1) sfdom(end)]), ylim([sfdom(1) sfdom(end)])
axis square
id = find(~isnan(tcP.sfBWA.*tcP.sfBWB));
[r p] = corrcoef(log2(tcP.sfBWA),log2(tcP.sfBWB));
title(['r=' num2str(round(r(1,2)*100)/100) '; p=' num2str(p(1,2))])


legend('unity','color-lum','lum','color')

subplot(5,2,10)
histogram(log2(tcP.sfBWA./tcP.sfBWB),[-4:.5:4],'FaceColor',[1 1 1])
set(gca,'TickDir','out')
mu = nanmean(log2(tcP.sfBWA./tcP.sfBWB));
[hyp p] = ttest(log2(tcP.sfBWA./tcP.sfBWB));
title(['geomu=' num2str(2.^mu) ' p=' num2str(p)])
xlabel('log(x)-log(y)')


%SFfit_percYield = length(idB)/length(tcP.sfprefA)
